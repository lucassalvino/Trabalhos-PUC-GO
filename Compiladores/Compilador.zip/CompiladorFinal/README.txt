ao executar o programa, acesse o menu op��es -> Carregar Tabela, navegue at� onde se encontra o arquivo com as produ��es e a tabela de entrada. Conforme segue arquivo de exemplo ("teste.txt").

Caso seja carregado sem nenhum erro. a tabela ser� exibida na tela inicial do programa.

Digite a palavra no input line abaixo da tabela, para acompanhar o teste da palavra na tabela, clique em Pr�ximo passo.
A cada click uma nova linha ser� exibida na tabela de sa�da. Acompanhe a execu��o da mesma por essa tabela. Caso a palavra n�o seja v�lida ser� exibido um message box informando o erro ocorrido.

Caso a palavra seja v�lida, tamb�m ser� exibido um message box infromando que a palavra � v�lida.]


O Bot�o Submit n�o foi implementado